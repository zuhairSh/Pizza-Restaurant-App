﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyWindowForm_Cours14
{
    public partial class Calculator_Form : Form
    {
        

        public Calculator_Form()
        {
            InitializeComponent();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you're coming back ?", "The Back",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Form MyForm = new MainForm();
                MyForm.Show();
                this.Close();
            }
            else
                return;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text += 1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text += 2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text += 3;        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text += 4;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text += 5;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text += 6;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Text += 7;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text += 8;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text += 9;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            textBox1.Text += 0;
        }

        int Number1 = 0;
        int Number2 = 0;
        string Operation = " ";

        private void button13_Click(object sender, EventArgs e)
        {
            Number1 = Convert.ToInt32(textBox1.Text);
            Operation = "+";
            textBox1.Text += " + ";
            textBox1.Clear();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Number1 = Convert.ToInt32(textBox1.Text);
            Operation = "-";
            textBox1.Text += " - ";
            textBox1.Clear();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Number1 = Convert.ToInt32(textBox1.Text);
            Operation = "*";
            textBox1.Text += " x ";
            textBox1.Clear();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Number1 = Convert.ToInt32(textBox1.Text);
            Operation = "/";
            textBox1.Text += " / ";
            textBox1.Clear();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Operation = "%";
            Number1 = Convert.ToInt32(textBox1.Text);
            textBox1.Text += " Mod ";
            textBox1.Clear();
        }

        private double ResultCalculattor()
        {
            switch (Operation)
            {
                case "+":
                    return Number1 + Number2;

                case "-":
                    return Number1 - Number2;

                case "*":
                    return Number1 * Number2;

                case "/":
                    return Number2 != 0 ? (double)Number1 / Number2 : 0;

                case "%":
                    return Number1 % Number2;

                default: return 0;
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            
            Number2 = Convert.ToInt32(textBox1.Text);

            double Result = ResultCalculattor();

            textBox1.Text = Result.ToString();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

    }
}
