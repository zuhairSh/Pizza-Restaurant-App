﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyWindowForm_Cours14
{
    public partial class Pizza_Form : Form
    {
        public Pizza_Form()
        {
            InitializeComponent();


            MakeAllTransparent(this);
        }

        void MakeAllTransparent(Control container)
        {
            foreach (Control c in container.Controls)
            {
                // افحص اسم الليبل هنا.. استبدل الاسم بأسماء الليبلات التي لا تريد إخفاءها
                if (c.Name == "label1" || c.Name == "label9" || c.Name == "label5")
                {
                    // لا تفعل شيئاً لهذين الليبلين واتركهما كما هما في الـ Designer
                    continue;
                }

                // باقي العناصر اجعلها شفافة
                c.BackColor = Color.Transparent;

                if (c.HasChildren)
                {
                    MakeAllTransparent(c);
                }
            }
        }

        private float PriceSize()
        {
            if (Small.Checked)
            {
                return Convert.ToSingle(Small.Tag);
            }
            else if (Meduim.Checked)
            {
                return Convert.ToSingle(Meduim.Tag);
            }
            else if (Larg.Checked)
            {
                return Convert.ToSingle(Larg.Tag);
            }

            return 0;
        }

        private float PriceCrust()
        {
            if (ThinCrust.Checked)
            {
                return Convert.ToSingle(ThinCrust.Tag);
            }
            else if(ThinkCrust.Checked)
            {
                return Convert.ToSingle(ThinkCrust.Tag);
            }
            return 0;
        }

        private float PriceTopping()
        {
            float TotalTopping = 0;

            if (checkExtraChees.Checked)
            {
                TotalTopping += Convert.ToSingle(checkExtraChees.Tag);
            }
            if (checkMushroom.Checked)
            {
                TotalTopping += Convert.ToSingle(checkMushroom.Tag);
            }
            if (checkOnion.Checked)
            {
                TotalTopping += Convert.ToSingle(checkOnion.Tag);
            }
            if (checkTometoes.Checked)
            {
                TotalTopping += Convert.ToSingle(checkTometoes.Tag);
            }

            return TotalTopping;
        }

        float CalculeterAllPrice()
        {
            return PriceSize() + PriceCrust() + PriceTopping();
        }

        void UptateLabelPrice()
        {
            labPrice.Text = CalculeterAllPrice().ToString() + "$";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure about the order?", "Confirm the order" 
                ,MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
            {
                groupSize.Enabled = false;
                groupTopping.Enabled = false;
                groupCrust.Enabled = false;
                groupEat.Enabled = false;
                button1.Enabled = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            groupSize.Enabled = true;
            groupTopping.Enabled = true;
            groupCrust.Enabled = true;
            groupEat.Enabled = true;
            button1.Enabled = true;
        }

        void UpdateSize()
        {
            UptateLabelPrice();
            
            if (Small.Checked)
            {
                labelSize.Text = "Small";
            }
            else if (Meduim.Checked)
            {
                labelSize.Text = "Meduim";
            }
            else if (Larg.Checked)
            {
                labelSize.Text = "Larg";
            }
        }

        void UpdateCrust()
        {
            UptateLabelPrice();

            if (ThinCrust.Checked)
            {
                labelTypeCrust.Text = "Thin Crust";
            }
            else if (ThinkCrust.Checked)
            {
                labelTypeCrust.Text = "Think Crust";
            }
        }

        void UpdateTopping()
        {
            string Topping = null;

            UptateLabelPrice();

            if (checkExtraChees.Checked)
            {
                Topping += "Extra Chees";
            }
            if (checkMushroom.Checked)
            {
                Topping += ", Mushroom";
            }
            if (checkOnion.Checked)
            {
                Topping += "\n, Onion";
            }
            if (checkTometoes.Checked)
            {
                Topping += ", Tometoes";
            }

            labelTopping.Text = Topping;
        }

        void UpdateWhereEat()
        {
            UptateLabelPrice();

            if (radioButton1.Checked)
            {
                labelToEat.Text = "Eat In";
            }
            if (radioButton2.Checked)
            {
                labelToEat.Text = "Take Out";
            }
        }


        private void Small_CheckedChanged(object sender, EventArgs e)
        {
            UpdateSize();
        }

        private void Meduim_CheckedChanged(object sender, EventArgs e)
        {
            UpdateSize();
        }

        private void Larg_CheckedChanged(object sender, EventArgs e)
        {
            UpdateSize();
        }

        private void ThinCrust_CheckedChanged(object sender, EventArgs e)
        {
            UpdateCrust();
        }

        private void ThinkCrust_CheckedChanged(object sender, EventArgs e)
        {
            UpdateCrust();
        }

        private void checkExtraChees_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTopping();
        }

        private void checkOnion_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTopping();
        }

        private void checkMushroom_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTopping();
        }

        private void checkTometoes_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTopping();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            UpdateWhereEat();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            UpdateWhereEat();
        }

    }
}
