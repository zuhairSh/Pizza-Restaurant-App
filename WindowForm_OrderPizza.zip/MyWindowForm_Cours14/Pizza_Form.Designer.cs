﻿
namespace MyWindowForm_Cours14
{
    partial class Pizza_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Pizza_Form));
            this.labSize = new System.Windows.Forms.Label();
            this.Small = new System.Windows.Forms.RadioButton();
            this.Meduim = new System.Windows.Forms.RadioButton();
            this.Larg = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.groupEat = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.groupCrust = new System.Windows.Forms.GroupBox();
            this.ThinkCrust = new System.Windows.Forms.RadioButton();
            this.ThinCrust = new System.Windows.Forms.RadioButton();
            this.groupSize = new System.Windows.Forms.GroupBox();
            this.groupTopping = new System.Windows.Forms.GroupBox();
            this.checkExtraChees = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.checkMushroom = new System.Windows.Forms.CheckBox();
            this.checkOnion = new System.Windows.Forms.CheckBox();
            this.checkTometoes = new System.Windows.Forms.CheckBox();
            this.labPrice = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelToEat = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.labelTypeCrust = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.groupToppings = new System.Windows.Forms.GroupBox();
            this.labelTopping = new System.Windows.Forms.Label();
            this.labelSize = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupEat.SuspendLayout();
            this.groupCrust.SuspendLayout();
            this.groupSize.SuspendLayout();
            this.groupTopping.SuspendLayout();
            this.groupToppings.SuspendLayout();
            this.SuspendLayout();
            // 
            // labSize
            // 
            this.labSize.AutoSize = true;
            this.labSize.BackColor = System.Drawing.Color.Maroon;
            this.labSize.Font = new System.Drawing.Font("Segoe UI Black", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labSize.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labSize.Location = new System.Drawing.Point(-5, 0);
            this.labSize.Name = "labSize";
            this.labSize.Size = new System.Drawing.Size(74, 21);
            this.labSize.TabIndex = 5;
            this.labSize.Text = "The Size";
            // 
            // Small
            // 
            this.Small.AutoSize = true;
            this.Small.BackColor = System.Drawing.Color.Brown;
            this.Small.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Small.ForeColor = System.Drawing.Color.FloralWhite;
            this.Small.Location = new System.Drawing.Point(51, 30);
            this.Small.Name = "Small";
            this.Small.Size = new System.Drawing.Size(73, 27);
            this.Small.TabIndex = 6;
            this.Small.Tag = "20";
            this.Small.Text = "Small";
            this.Small.UseVisualStyleBackColor = false;
            this.Small.CheckedChanged += new System.EventHandler(this.Small_CheckedChanged);
            // 
            // Meduim
            // 
            this.Meduim.AutoSize = true;
            this.Meduim.BackColor = System.Drawing.Color.Brown;
            this.Meduim.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Meduim.ForeColor = System.Drawing.SystemColors.Window;
            this.Meduim.Location = new System.Drawing.Point(51, 60);
            this.Meduim.Name = "Meduim";
            this.Meduim.Size = new System.Drawing.Size(92, 27);
            this.Meduim.TabIndex = 7;
            this.Meduim.Tag = "30";
            this.Meduim.Text = "Meduim";
            this.Meduim.UseVisualStyleBackColor = false;
            this.Meduim.CheckedChanged += new System.EventHandler(this.Meduim_CheckedChanged);
            // 
            // Larg
            // 
            this.Larg.AutoSize = true;
            this.Larg.BackColor = System.Drawing.Color.Brown;
            this.Larg.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Larg.ForeColor = System.Drawing.SystemColors.Window;
            this.Larg.Location = new System.Drawing.Point(51, 90);
            this.Larg.Name = "Larg";
            this.Larg.Size = new System.Drawing.Size(62, 27);
            this.Larg.TabIndex = 8;
            this.Larg.Tag = "40";
            this.Larg.Text = "Larg";
            this.Larg.UseVisualStyleBackColor = false;
            this.Larg.CheckedChanged += new System.EventHandler(this.Larg_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Maroon;
            this.label2.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "Crust Type";
            // 
            // groupEat
            // 
            this.groupEat.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.groupEat.Controls.Add(this.radioButton1);
            this.groupEat.Controls.Add(this.label4);
            this.groupEat.Controls.Add(this.radioButton2);
            this.groupEat.Location = new System.Drawing.Point(253, 261);
            this.groupEat.Name = "groupEat";
            this.groupEat.Size = new System.Drawing.Size(200, 100);
            this.groupEat.TabIndex = 36;
            this.groupEat.TabStop = false;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.BackColor = System.Drawing.Color.Brown;
            this.radioButton1.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.radioButton1.Location = new System.Drawing.Point(6, 55);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(63, 24);
            this.radioButton1.TabIndex = 18;
            this.radioButton1.TabStop = true;
            this.radioButton1.Tag = "0";
            this.radioButton1.Text = "Eat In";
            this.radioButton1.UseVisualStyleBackColor = false;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Maroon;
            this.label4.Font = new System.Drawing.Font("Segoe Print", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(1, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(149, 33);
            this.label4.TabIndex = 17;
            this.label4.Text = "Where To Eat";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.BackColor = System.Drawing.Color.Brown;
            this.radioButton2.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.ForeColor = System.Drawing.SystemColors.MenuText;
            this.radioButton2.Location = new System.Drawing.Point(100, 55);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(82, 24);
            this.radioButton2.TabIndex = 19;
            this.radioButton2.TabStop = true;
            this.radioButton2.Tag = "0";
            this.radioButton2.Text = "Take Out";
            this.radioButton2.UseVisualStyleBackColor = false;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // groupCrust
            // 
            this.groupCrust.BackColor = System.Drawing.Color.Bisque;
            this.groupCrust.Controls.Add(this.label2);
            this.groupCrust.Controls.Add(this.ThinkCrust);
            this.groupCrust.Controls.Add(this.ThinCrust);
            this.groupCrust.Location = new System.Drawing.Point(12, 253);
            this.groupCrust.Name = "groupCrust";
            this.groupCrust.Size = new System.Drawing.Size(200, 100);
            this.groupCrust.TabIndex = 35;
            this.groupCrust.TabStop = false;
            // 
            // ThinkCrust
            // 
            this.ThinkCrust.AutoSize = true;
            this.ThinkCrust.BackColor = System.Drawing.Color.Brown;
            this.ThinkCrust.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThinkCrust.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.ThinkCrust.Location = new System.Drawing.Point(44, 70);
            this.ThinkCrust.Name = "ThinkCrust";
            this.ThinkCrust.Size = new System.Drawing.Size(117, 27);
            this.ThinkCrust.TabIndex = 11;
            this.ThinkCrust.TabStop = true;
            this.ThinkCrust.Tag = "10";
            this.ThinkCrust.Text = "Think Crust";
            this.ThinkCrust.UseVisualStyleBackColor = false;
            this.ThinkCrust.CheckedChanged += new System.EventHandler(this.ThinkCrust_CheckedChanged);
            // 
            // ThinCrust
            // 
            this.ThinCrust.AutoSize = true;
            this.ThinCrust.BackColor = System.Drawing.Color.Brown;
            this.ThinCrust.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThinCrust.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.ThinCrust.Location = new System.Drawing.Point(44, 40);
            this.ThinCrust.Name = "ThinCrust";
            this.ThinCrust.Size = new System.Drawing.Size(108, 27);
            this.ThinCrust.TabIndex = 10;
            this.ThinCrust.TabStop = true;
            this.ThinCrust.Tag = "0";
            this.ThinCrust.Text = "Thin Crust";
            this.ThinCrust.UseVisualStyleBackColor = false;
            this.ThinCrust.CheckedChanged += new System.EventHandler(this.ThinCrust_CheckedChanged);
            // 
            // groupSize
            // 
            this.groupSize.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.groupSize.Controls.Add(this.labSize);
            this.groupSize.Controls.Add(this.Meduim);
            this.groupSize.Controls.Add(this.Larg);
            this.groupSize.Controls.Add(this.Small);
            this.groupSize.Location = new System.Drawing.Point(12, 101);
            this.groupSize.Name = "groupSize";
            this.groupSize.Size = new System.Drawing.Size(200, 120);
            this.groupSize.TabIndex = 34;
            this.groupSize.TabStop = false;
            // 
            // groupTopping
            // 
            this.groupTopping.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.groupTopping.Controls.Add(this.checkExtraChees);
            this.groupTopping.Controls.Add(this.label3);
            this.groupTopping.Controls.Add(this.checkMushroom);
            this.groupTopping.Controls.Add(this.checkOnion);
            this.groupTopping.Controls.Add(this.checkTometoes);
            this.groupTopping.Location = new System.Drawing.Point(218, 114);
            this.groupTopping.Name = "groupTopping";
            this.groupTopping.Size = new System.Drawing.Size(287, 127);
            this.groupTopping.TabIndex = 33;
            this.groupTopping.TabStop = false;
            // 
            // checkExtraChees
            // 
            this.checkExtraChees.AutoSize = true;
            this.checkExtraChees.BackColor = System.Drawing.Color.Brown;
            this.checkExtraChees.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkExtraChees.ForeColor = System.Drawing.Color.Black;
            this.checkExtraChees.Location = new System.Drawing.Point(37, 44);
            this.checkExtraChees.Name = "checkExtraChees";
            this.checkExtraChees.Size = new System.Drawing.Size(104, 24);
            this.checkExtraChees.TabIndex = 12;
            this.checkExtraChees.Tag = "5";
            this.checkExtraChees.Text = "Extra Chees";
            this.checkExtraChees.UseVisualStyleBackColor = false;
            this.checkExtraChees.CheckedChanged += new System.EventHandler(this.checkExtraChees_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Maroon;
            this.label3.Font = new System.Drawing.Font("Segoe Script", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label3.Location = new System.Drawing.Point(-5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 31);
            this.label3.TabIndex = 13;
            this.label3.Text = "Toppings";
            // 
            // checkMushroom
            // 
            this.checkMushroom.AutoSize = true;
            this.checkMushroom.BackColor = System.Drawing.Color.Brown;
            this.checkMushroom.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkMushroom.ForeColor = System.Drawing.Color.Black;
            this.checkMushroom.Location = new System.Drawing.Point(37, 85);
            this.checkMushroom.Name = "checkMushroom";
            this.checkMushroom.Size = new System.Drawing.Size(105, 24);
            this.checkMushroom.TabIndex = 14;
            this.checkMushroom.Tag = "5";
            this.checkMushroom.Text = "Mushrooms";
            this.checkMushroom.UseVisualStyleBackColor = false;
            this.checkMushroom.CheckedChanged += new System.EventHandler(this.checkMushroom_CheckedChanged);
            // 
            // checkOnion
            // 
            this.checkOnion.AutoSize = true;
            this.checkOnion.BackColor = System.Drawing.Color.Brown;
            this.checkOnion.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkOnion.ForeColor = System.Drawing.SystemColors.Desktop;
            this.checkOnion.Location = new System.Drawing.Point(169, 46);
            this.checkOnion.Name = "checkOnion";
            this.checkOnion.Size = new System.Drawing.Size(65, 24);
            this.checkOnion.TabIndex = 15;
            this.checkOnion.Tag = "5";
            this.checkOnion.Text = "Onion";
            this.checkOnion.UseVisualStyleBackColor = false;
            this.checkOnion.CheckedChanged += new System.EventHandler(this.checkOnion_CheckedChanged);
            // 
            // checkTometoes
            // 
            this.checkTometoes.AutoSize = true;
            this.checkTometoes.BackColor = System.Drawing.Color.Brown;
            this.checkTometoes.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkTometoes.ForeColor = System.Drawing.Color.Black;
            this.checkTometoes.Location = new System.Drawing.Point(169, 85);
            this.checkTometoes.Name = "checkTometoes";
            this.checkTometoes.Size = new System.Drawing.Size(92, 24);
            this.checkTometoes.TabIndex = 16;
            this.checkTometoes.Tag = "5";
            this.checkTometoes.Text = "Tomatoes";
            this.checkTometoes.UseVisualStyleBackColor = false;
            this.checkTometoes.CheckedChanged += new System.EventHandler(this.checkTometoes_CheckedChanged);
            // 
            // labPrice
            // 
            this.labPrice.AutoSize = true;
            this.labPrice.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labPrice.Font = new System.Drawing.Font("Impact", 21.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labPrice.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labPrice.Location = new System.Drawing.Point(689, 363);
            this.labPrice.Name = "labPrice";
            this.labPrice.Size = new System.Drawing.Size(31, 36);
            this.labPrice.TabIndex = 32;
            this.labPrice.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.LightSalmon;
            this.label7.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.MenuText;
            this.label7.Location = new System.Drawing.Point(536, 373);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 25);
            this.label7.TabIndex = 31;
            this.label7.Text = "Total Price : ";
            // 
            // labelToEat
            // 
            this.labelToEat.AutoSize = true;
            this.labelToEat.BackColor = System.Drawing.Color.BurlyWood;
            this.labelToEat.Font = new System.Drawing.Font("Myanmar Text", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelToEat.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelToEat.Location = new System.Drawing.Point(690, 319);
            this.labelToEat.Name = "labelToEat";
            this.labelToEat.Size = new System.Drawing.Size(17, 29);
            this.labelToEat.TabIndex = 30;
            this.labelToEat.Text = " ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.BurlyWood;
            this.label8.Font = new System.Drawing.Font("Myanmar Text", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(570, 319);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 29);
            this.label8.TabIndex = 29;
            this.label8.Text = "Where To Eat";
            // 
            // labelTypeCrust
            // 
            this.labelTypeCrust.AutoSize = true;
            this.labelTypeCrust.BackColor = System.Drawing.Color.BurlyWood;
            this.labelTypeCrust.Font = new System.Drawing.Font("Myanmar Text", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTypeCrust.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelTypeCrust.Location = new System.Drawing.Point(669, 280);
            this.labelTypeCrust.Name = "labelTypeCrust";
            this.labelTypeCrust.Size = new System.Drawing.Size(17, 29);
            this.labelTypeCrust.TabIndex = 28;
            this.labelTypeCrust.Text = " ";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.BackColor = System.Drawing.Color.BurlyWood;
            this.label.Font = new System.Drawing.Font("Myanmar Text", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label.Location = new System.Drawing.Point(570, 277);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(93, 29);
            this.label.TabIndex = 27;
            this.label.Text = "Crust Type";
            // 
            // groupToppings
            // 
            this.groupToppings.BackColor = System.Drawing.Color.BurlyWood;
            this.groupToppings.Controls.Add(this.labelTopping);
            this.groupToppings.Font = new System.Drawing.Font("Microsoft PhagsPa", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupToppings.ForeColor = System.Drawing.Color.Black;
            this.groupToppings.Location = new System.Drawing.Point(563, 141);
            this.groupToppings.Name = "groupToppings";
            this.groupToppings.Size = new System.Drawing.Size(200, 100);
            this.groupToppings.TabIndex = 26;
            this.groupToppings.TabStop = false;
            this.groupToppings.Text = "Topping  : ";
            // 
            // labelTopping
            // 
            this.labelTopping.AutoSize = true;
            this.labelTopping.Location = new System.Drawing.Point(10, 23);
            this.labelTopping.Name = "labelTopping";
            this.labelTopping.Size = new System.Drawing.Size(13, 20);
            this.labelTopping.TabIndex = 0;
            this.labelTopping.Text = " ";
            // 
            // labelSize
            // 
            this.labelSize.AutoSize = true;
            this.labelSize.BackColor = System.Drawing.Color.BurlyWood;
            this.labelSize.Font = new System.Drawing.Font("Myanmar Text", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSize.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelSize.Location = new System.Drawing.Point(620, 106);
            this.labelSize.Name = "labelSize";
            this.labelSize.Size = new System.Drawing.Size(17, 29);
            this.labelSize.TabIndex = 24;
            this.labelSize.Text = " ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.BurlyWood;
            this.label6.Font = new System.Drawing.Font("Myanmar Text", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(570, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 29);
            this.label6.TabIndex = 23;
            this.label6.Text = "Size";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Moccasin;
            this.label5.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(549, 64);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(176, 29);
            this.label5.TabIndex = 22;
            this.label5.Text = "Order Summary :";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Bisque;
            this.button2.Font = new System.Drawing.Font("Sylfaen", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button2.Location = new System.Drawing.Point(346, 371);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(143, 33);
            this.button2.TabIndex = 21;
            this.button2.Text = "Reset Form";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Bisque;
            this.button1.Font = new System.Drawing.Font("Sylfaen", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(136, 371);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(143, 33);
            this.button1.TabIndex = 20;
            this.button1.Text = "Order Pizza";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Moccasin;
            this.label1.Font = new System.Drawing.Font("Segoe Script", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Brown;
            this.label1.Location = new System.Drawing.Point(-5, -6);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(381, 80);
            this.label1.TabIndex = 4;
            this.label1.Text = "Menu Pizza  ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Moccasin;
            this.label9.Font = new System.Drawing.Font("Segoe Script", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Brown;
            this.label9.Location = new System.Drawing.Point(363, -6);
            this.label9.Name = "label9";
            this.label9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label9.Size = new System.Drawing.Size(452, 80);
            this.label9.TabIndex = 11;
            this.label9.Text = "                      ";
            // 
            // Pizza_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(806, 424);
            this.Controls.Add(this.groupEat);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupCrust);
            this.Controls.Add(this.groupSize);
            this.Controls.Add(this.groupTopping);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.labPrice);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelToEat);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.labelSize);
            this.Controls.Add(this.labelTypeCrust);
            this.Controls.Add(this.groupToppings);
            this.Controls.Add(this.label);
            this.Controls.Add(this.label9);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Pizza_Form";
            this.Text = "Pizza_Form";
            this.groupEat.ResumeLayout(false);
            this.groupEat.PerformLayout();
            this.groupCrust.ResumeLayout(false);
            this.groupCrust.PerformLayout();
            this.groupSize.ResumeLayout(false);
            this.groupSize.PerformLayout();
            this.groupTopping.ResumeLayout(false);
            this.groupTopping.PerformLayout();
            this.groupToppings.ResumeLayout(false);
            this.groupToppings.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labSize;
        private System.Windows.Forms.RadioButton Small;
        private System.Windows.Forms.RadioButton Meduim;
        private System.Windows.Forms.RadioButton Larg;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton ThinCrust;
        private System.Windows.Forms.RadioButton ThinkCrust;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkExtraChees;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkTometoes;
        private System.Windows.Forms.CheckBox checkOnion;
        private System.Windows.Forms.CheckBox checkMushroom;
        private System.Windows.Forms.Label labelSize;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupToppings;
        private System.Windows.Forms.Label labelTypeCrust;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label labelToEat;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labPrice;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupCrust;
        private System.Windows.Forms.GroupBox groupSize;
        private System.Windows.Forms.GroupBox groupTopping;
        private System.Windows.Forms.GroupBox groupEat;
        private System.Windows.Forms.Label labelTopping;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
    }
}